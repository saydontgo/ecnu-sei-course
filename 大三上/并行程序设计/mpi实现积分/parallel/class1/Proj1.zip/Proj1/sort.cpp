#include <iostream>
#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>

using namespace std;
 
int main(int argc, char *argv[])
{
    int numprocessors, rank, namelen;
    char processor_name[MPI_MAX_PROCESSOR_NAME];
 
    MPI_Init(&argc, &argv);
    MPI_Comm_size(MPI_COMM_WORLD, &numprocessors);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Get_processor_name(processor_name, &namelen);

    int init_buffer[10];

    for(int i=0;i<10;i++)
	init_buffer[i]=rand()%10;

    cout<<"[";
    for(int i=0;i<10;i++)
        cout<<init_buffer[i]<<",";
	cout<<"]\n";

    if ( rank == 0 )
    {
	int * array=new int[2];
	
        //your code goes here;
	
	delete[] array;

    } else {
	int * array=new int[2];
	
        //your code goes here;
	
	delete[] array;
   }
   MPI_Finalize();
   return 0;
}
