#include <iostream>
#include <mpi.h>


using namespace std;
 
int main(int argc, char *argv[])
{
    int numprocessors, rank, namelen;
    char processor_name[MPI_MAX_PROCESSOR_NAME];
 
    MPI_Init(&argc, &argv);
    MPI_Comm_size(MPI_COMM_WORLD, &numprocessors);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Get_processor_name(processor_name, &namelen);

    int data = rank+1;
    int local_int=0;

    MPI_Bcast(&data, 1, MPI_INT, 0, MPI_COMM_WORLD);

    if ( rank == 0 )
    {
    	cout <<"send a data: " <<data<<endl;
    } else {
        cout << "slave  (" << rank << "/" << numprocessors << ") has a receive "<<data<<endl;
   }
   MPI_Finalize();
   return 0;
}
