call "%VS90COMNTOOLS%\vsvars32.bat" 
nmake -f car_sfun.mak
