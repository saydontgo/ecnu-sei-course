#ifndef __c2_tempParallelStart_h__
#define __c2_tempParallelStart_h__

/* Include files */
#include "sfc_sf.h"
#include "sfc_mex.h"
#include "rtwtypes.h"

/* Type Definitions */
#ifndef typedef_SFc2_tempParallelStartInstanceStruct
#define typedef_SFc2_tempParallelStartInstanceStruct

typedef struct {
  SimStruct *S;
  ChartInfoStruct chartInfo;
  uint32_T chartNumber;
  uint32_T instanceNumber;
  int32_T c2_sfEvent;
  uint8_T c2_tp_Off;
  uint8_T c2_tp_HeaterOn;
  uint8_T c2_tp_CoolerOn;
  uint8_T c2_tp_humid_off;
  uint8_T c2_tp_humid_on;
  uint8_T c2_tp_humid_off1;
  uint8_T c2_tp_humid_on1;
  uint8_T c2_tp_aggressive;
  uint8_T c2_tp_nonaggressive;
  uint8_T c2_tp_B;
  uint8_T c2_tp_A;
  uint8_T c2_tp_C;
  boolean_T c2_isStable;
  uint8_T c2_is_active_c2_tempParallelStart;
  uint8_T c2_is_c2_tempParallelStart;
  uint8_T c2_is_HeaterOn;
  uint8_T c2_is_CoolerOn;
  uint8_T c2_is_B;
  uint8_T c2_is_active_B;
  uint8_T c2_is_A;
  uint8_T c2_is_active_A;
  real_T c2_dT;
  uint8_T c2_doSetSimStateSideEffects;
  const mxArray *c2_setSimStateSideEffectsInfo;
} SFc2_tempParallelStartInstanceStruct;

#endif                                 /*typedef_SFc2_tempParallelStartInstanceStruct*/

/* Named Constants */

/* Variable Declarations */

/* Variable Definitions */

/* Function Declarations */
extern const mxArray *sf_c2_tempParallelStart_get_eml_resolved_functions_info
  (void);

/* Function Definitions */
extern void sf_c2_tempParallelStart_get_check_sum(mxArray *plhs[]);
extern void c2_tempParallelStart_method_dispatcher(SimStruct *S, int_T method,
  void *data);

#endif
