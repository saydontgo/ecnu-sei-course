call "%VS90COMNTOOLS%\vsvars32.bat" 
nmake -f abort_logic_start_sfun.mak
