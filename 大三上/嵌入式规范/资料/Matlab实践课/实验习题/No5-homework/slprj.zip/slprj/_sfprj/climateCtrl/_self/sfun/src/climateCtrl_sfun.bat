call "%VS90COMNTOOLS%\vsvars32.bat" 
nmake -f climateCtrl_sfun.mak
