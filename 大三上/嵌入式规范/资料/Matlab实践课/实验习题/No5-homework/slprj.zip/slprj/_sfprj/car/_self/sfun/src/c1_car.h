#ifndef __c1_car_h__
#define __c1_car_h__

/* Include files */
#include "sfc_sf.h"
#include "sfc_mex.h"
#include "rtwtypes.h"

/* Type Definitions */
#ifndef typedef_SFc1_carInstanceStruct
#define typedef_SFc1_carInstanceStruct

typedef struct {
  SimStruct *S;
  ChartInfoStruct chartInfo;
  uint32_T chartNumber;
  uint32_T instanceNumber;
  int32_T c1_sfEvent;
  uint8_T c1_tp_State1;
  uint8_T c1_tp_Start;
  uint8_T c1_tp_State2;
  uint8_T c1_tp_State3;
  boolean_T c1_isStable;
  uint8_T c1_is_active_c1_car;
  uint8_T c1_is_c1_car;
  real_T c1_shift;
  uint8_T c1_doSetSimStateSideEffects;
  const mxArray *c1_setSimStateSideEffectsInfo;
} SFc1_carInstanceStruct;

#endif                                 /*typedef_SFc1_carInstanceStruct*/

/* Named Constants */

/* Variable Declarations */

/* Variable Definitions */

/* Function Declarations */
extern const mxArray *sf_c1_car_get_eml_resolved_functions_info(void);

/* Function Definitions */
extern void sf_c1_car_get_check_sum(mxArray *plhs[]);
extern void c1_car_method_dispatcher(SimStruct *S, int_T method, void *data);

#endif
