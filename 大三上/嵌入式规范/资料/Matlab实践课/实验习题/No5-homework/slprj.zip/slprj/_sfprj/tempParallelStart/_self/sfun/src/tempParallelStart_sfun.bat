call "%VS90COMNTOOLS%\vsvars32.bat" 
nmake -f tempParallelStart_sfun.mak
