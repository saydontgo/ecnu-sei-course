#ifndef __c2_climateCtrl_h__
#define __c2_climateCtrl_h__

/* Include files */
#include "sfc_sf.h"
#include "sfc_mex.h"
#include "rtwtypes.h"

/* Type Definitions */
#ifndef typedef_SFc2_climateCtrlInstanceStruct
#define typedef_SFc2_climateCtrlInstanceStruct

typedef struct {
  SimStruct *S;
  ChartInfoStruct chartInfo;
  uint32_T chartNumber;
  uint32_T instanceNumber;
  int32_T c2_sfEvent;
  uint8_T c2_tp_Off;
  uint8_T c2_tp_HeaterOn;
  uint8_T c2_tp_CoolerOn;
  boolean_T c2_isStable;
  boolean_T c2_doneDoubleBufferReInit;
  uint8_T c2_is_active_c2_climateCtrl;
  uint8_T c2_is_c2_climateCtrl;
  real_T c2_dT;
  uint8_T c2_doSetSimStateSideEffects;
  const mxArray *c2_setSimStateSideEffectsInfo;
} SFc2_climateCtrlInstanceStruct;

#endif                                 /*typedef_SFc2_climateCtrlInstanceStruct*/

/* Named Constants */

/* Variable Declarations */

/* Variable Definitions */

/* Function Declarations */
extern const mxArray *sf_c2_climateCtrl_get_eml_resolved_functions_info(void);

/* Function Definitions */
extern void sf_c2_climateCtrl_get_check_sum(mxArray *plhs[]);
extern void c2_climateCtrl_method_dispatcher(SimStruct *S, int_T method, void
  *data);

#endif
