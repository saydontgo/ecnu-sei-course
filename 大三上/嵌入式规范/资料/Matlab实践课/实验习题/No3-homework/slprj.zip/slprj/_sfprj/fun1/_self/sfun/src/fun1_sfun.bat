call "%VS90COMNTOOLS%\vsvars32.bat" 
nmake -f fun1_sfun.mak
