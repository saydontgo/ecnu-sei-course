1.client要有读取txt文件的功能,即将给定的txt文件如iput.txt中保存的信息准确读取并发送到客户端.
2.server要有输出txt文件的功能,即将客户端所发送的信息输出到指定txt文件中,如oput.txt.
3.server需在后台循环等待,而client在读取并发送信息后即可终止.
4.注意文件的输入输出格式

共五个测试部分

1.简单的连接测试

client需要读取test_1目录下的iput.txt中的少量信息并发送至server,随后server将接收到的信息写入到当前目录下创建的oput.txt中.

如果io文件中的信息一致,即为功能正确实现.


2.长文本传输测试

client需要读取test_2目录下的iput.txt中的信息并发送至server,随后server将接收到的信息写入到当前目录下创建的oput.txt中.

如果io文件中的信息一致,即为功能正确实现.


3.二进制文件传输测试

client需要读取test_2目录下的iput.txt中的信息并发送至server,随后server将接收到的信息写入到当前目录下创建的oput.txt中.

如果io文件中的信息一致,即为功能正确实现.
注意:二进制文件虽然以txt形式保存,但并不能由txt按照字符文件来打开,如果要比较io文件的一致性,请使用文件比较函数.
linux下的diff命令:

	diff iput.txt oput.txt


4.多客户端连接测试

client需要按顺序读取test_4目录下的iput_0..2.txt三个文件并发送至server,随后server按照接收到的信息,按顺写入到当前目录下创建的oput.txt中.

如果io文件中的信息一致,即为功能正确实现


5.并发客户端传输测试

需要实现循环或并发读取test_5目录下的iput_0..9.txt中的信息并发送至server,随后server将接收到的信息写入到当前目录下创建的oput.txt中.

由于多客户端同时发送大量数据,不需要保证io文件中的信息行间的顺序一致性,可以使用排序功能将i和o文件进行行排序,来比较每行是否一致,来验证正确性.
注意:server端所进行的输出要保证一个客户端的输出仅在一行中,所以在读取每一个iput_文件时要将文本完整的传输,末尾换行符号同样视为传输信息,否则在正确性验证时无法分别报文行数.

linux下的sort命令:

    sort oput.txt -o oput_sorted.txt
